package com.BikkadIT.POC.POC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocApplicationTests {

	@Test
	void contextLoads() {
	}

}
